//
//  MoneyValue.swift
//  BlackJack
//
//  Created by James Tyner on 3/4/17.
//  Copyright © 2017 James Tyner. All rights reserved.
//

import Foundation

enum MoneyValue: Int{
    case ten = 10
    case twentyFive = 25
    case fifty = 50
}
