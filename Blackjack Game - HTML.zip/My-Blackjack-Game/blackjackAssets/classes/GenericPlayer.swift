//
//  GenericPlayer.swift
//  BlackJack
//
//  Created by James Tyner on 3/15/17.
//  Copyright © 2017 James Tyner. All rights reserved.
//

import Foundation

class GenericPlayer {
    var hand:Hand

    
    init(hand: Hand) {
        self.hand = hand

    }

}
