//
//  GenericPlayer.swift
//  My_Blackjack_Game
//
//  Created by Hunter Rollins on 11/28/21.
//


import Foundation

class GenericPlayer {
    var hand:Hand

    
    init(hand: Hand) {
        self.hand = hand

    }

}
