//
//  MoneyValue.swift
//  My_Blackjack_Game
//
//  Created by Hunter Rollins on 11/28/21.
//


import Foundation

enum MoneyValue: Int{
    case ten = 10
    case twentyFive = 25
    case fifty = 50
}
