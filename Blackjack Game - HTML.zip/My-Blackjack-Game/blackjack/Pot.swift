//
//  Pot.swift
//  My_Blackjack_Game
//
//  Created by Hunter Rollins on 11/28/21.
//


class Pot {
    private var pot = 0

    func addMoney(amount: Int){
        pot += amount
    }
    
    func getMoney()->Int{
        return pot
    }
    
    func reset(){
        pot = 0
    }

    
}
