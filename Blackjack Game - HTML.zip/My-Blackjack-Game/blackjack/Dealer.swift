//
//  Dealer.swift
//  My_Blackjack_Game
//
//  Created by Hunter Rollins on 11/28/21.
//


import Foundation

class Dealer: GenericPlayer{
   private var firstCard = Card(suit: "card_front",value: 0)
    
    override init(hand: Hand) {
       super.init(hand: hand)
    }
    
    func setFirstCard(card: Card){
        firstCard = card
    }
    
    func getFirstCard()->Card{
        return firstCard
    }
}
