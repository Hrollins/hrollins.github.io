//
//  Bank.swift
//  My_Blackjack_Game
//
//  Created by Hunter Rollins on 11/28/21.
//


import Foundation

class Bank {
    var balance = 500
    
    init() {
        
   }
    
    func resetBalance(){
        
        balance = 500
    }
    
    func addMoney(amount: Int){
        balance += amount
    }
    
    func subtractMoney(amount: Int){
        balance -= amount
        if(balance <= 10){
            resetBalance()
        }
    }
    
    func getBalance()->Int{
        return balance
    }
  }
